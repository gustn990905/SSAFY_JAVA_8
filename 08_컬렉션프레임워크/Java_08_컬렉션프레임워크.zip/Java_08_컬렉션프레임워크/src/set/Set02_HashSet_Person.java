package set;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

class Person {
	String name;
	int age;
	
	public Person() {
	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
//	@Override
//	public int hashCode() {
//		return Objects.hash(age, name);
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		Person p = (Person)obj;
//		if(p.name.equals(this.name)
//				&& p.age == this.age) {
//			return true;
//		}
//		return false;
//	}
	
	
	
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(age, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return age == other.age && Objects.equals(name, other.name);
	}
	
}


public class Set02_HashSet_Person {
	public static void main(String[] args) {
		Set<Person> set = new HashSet<>();
		
		set.add(new Person("양띵균", 45));
		set.add(new Person("양명균", 43));
		set.add(new Person("양명균", 43));
		set.add(new Person("양명균", 43));
		set.add(null);
		
		for(Person p: set) {
			System.out.println(p);
		}
		
		
		
		
		
		
		
		
		
		
		
	}
}
