package map;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class Map01_HashMap {
	
	public static void main(String[] args) {
		//Map: 사전 Key-Value 쌍으로 이루어져있음
		//Key 중복 x, Value 중복 o
		
		Map<String, String> map = new HashMap<>();
		
		map.put("양띵균", "Java");
		map.put("이정헌", "Java");
		map.put("이승재", "중국어");
		map.put("양명균", null);
		map.put("양예서", null);
		map.put("양명균", "한국어");
		
		
		System.out.println(map);
		
		
		System.out.println(map.keySet());
		map.get("Key"); //키만 알면 값을 접근할수 있죠
		
		
		System.out.println(map.containsKey("Key"));
		System.out.println(map.containsValue("Value"));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
