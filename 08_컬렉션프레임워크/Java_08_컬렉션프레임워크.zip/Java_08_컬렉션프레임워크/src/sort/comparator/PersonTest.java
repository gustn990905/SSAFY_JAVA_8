package sort.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PersonTest {
	public static void main(String[] args) {
		List<Person> list = new ArrayList<>();
		
		list.add(new Person("양", 45));
		list.add(new Person("김", 45));
		list.add(new Person("이", 20));
		list.add(new Person("조", 30));
		
		Collections.sort(list, new PersonComparator());
		//한번만 쓸래(익명 클래스)
		Collections.sort(list, new Comparator<Person>() {

			@Override
			public int compare(Person o1, Person o2) {
				return o1.age - o2.age;
			}
		});
		
		Collections.sort(list, (p1, p2) -> Integer.compare(p1.age, p2.age));
		
		
		for(Person p: list) {
			System.out.println(p);
		}
		
	}
}
