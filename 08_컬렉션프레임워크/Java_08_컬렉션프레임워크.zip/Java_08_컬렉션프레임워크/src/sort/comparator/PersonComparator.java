package sort.comparator;

import java.util.Comparator;

public class PersonComparator implements Comparator<Person> {

	//나이순으로 정렬하고 나이가 같다면 이름기준으로 정렬하자
	@Override
	public int compare(Person o1, Person o2) {
		if(o1.age == o2.age) {
			return o1.name.compareTo(o2.name);
		}
		return o1.age - o2.age; //나이기준 오름차순
	}

}
