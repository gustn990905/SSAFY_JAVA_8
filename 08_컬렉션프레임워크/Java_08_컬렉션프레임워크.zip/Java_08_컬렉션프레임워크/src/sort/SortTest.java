package sort;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortTest {
	public static void main(String[] args) {
		List<String> names = new ArrayList<>();
		names.add("천");
		names.add("김");
		names.add("도");
		names.add("이");
		names.add("차");
		names.add("서");
		names.add("허");
		names.add("박");
		
		System.out.println(names);
		
		Collections.sort(names);
		Collections.reverse(names);
		System.out.println(names);
		
		int[] nums = {5,0,1,5,6};
		Arrays.sort(nums);
		
		System.out.println(Arrays.toString(nums));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
