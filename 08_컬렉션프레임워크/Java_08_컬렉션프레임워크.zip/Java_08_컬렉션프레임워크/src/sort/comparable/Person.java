package sort.comparable;

public class Person implements Comparable<Person> {
	String name;
	int age;

	public Person() {
		// TODO Auto-generated constructor stub
	}

	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	


	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}



	@Override
	public int compareTo(Person o) {
		//나이만 가지고 이야기 해보자
		// 값이 0 같다
		// 양수면 크다
		// 음수면 작다
//		if(this.age == o.age)return 0;
//		else if(this.age > o.age) return 1;
//		else return -1;
		
		//보통은 아래와 같이 작성한다. (오름차순)
//		return this.age - o.age;
		//내림차순
//		return o.age - this.age;
//		return -(this.age - o.age);
		return Integer.compare(age, o.age);
		
	}
	
	
	
	
	
	
	
	
	
	
	

}
