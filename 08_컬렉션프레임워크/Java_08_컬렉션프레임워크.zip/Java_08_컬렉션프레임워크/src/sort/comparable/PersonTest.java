package sort.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PersonTest {
	public static void main(String[] args) {
		List<Person> list = new ArrayList<>();
		
		list.add(new Person("양", 45));
		list.add(new Person("이", 20));
		list.add(new Person("조", 30));
		
		Collections.sort(list);
		
		for(Person p: list) {
			System.out.println(p);
		}
		
	}
}
